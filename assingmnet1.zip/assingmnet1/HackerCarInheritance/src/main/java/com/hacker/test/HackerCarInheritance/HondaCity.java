package com.hacker.test.HackerCarInheritance;

public class HondaCity extends Car{
	
String carmileage;
	
	public HondaCity(boolean isSedan, String seats, String mileage) {
		super(isSedan, seats);
		this.carmileage = mileage;
	}

	@Override
	public String getMileage() {
		return this.carmileage;
	}

}
