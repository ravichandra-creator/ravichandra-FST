package com.hacker.test.HackerCarInheritance;

import java.util.Scanner;
/**
 * Hello world!
 *
 */
public class App 
{
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		int carid = Integer.parseInt(scr.next());
		String carmileage = scr.next();
		scr.close();
		switch (carid) {
		case 0:
			WagonR wr = new WagonR(false, "4", carmileage);
			String sdn = wr.getIsSedan() ? "is" : " is not";
			System.out.println("A WagonR "+sdn+" Sedan, is "+wr.getSeats()+"-seater, and has a mileage of around "+wr.getMileage()+" kmpl.");
			break;
		case 1:
			HondaCity hc = new HondaCity(true, "4", carmileage);
			String sdn1 = hc.getIsSedan() ? "is" : " is not";
			System.out.println("A Hondacity "+sdn1+" Sedan, is "+hc.getSeats()+"-seater, and has a mileage of around "+hc.getMileage()+" kmpl.");
			break;
		case 2:
			InnovaCrysta ic = new InnovaCrysta(true, "6", carmileage);
			String sdn2 = ic.getIsSedan() ? "is" : " is not";
			System.out.println("A Innova "+sdn2+" Sedan, is "+ic.getSeats()+"-seater, and has a mileage of around "+ic.getMileage()+" kmpl.");
			break;
		default:
			break;
		}

	}

}
