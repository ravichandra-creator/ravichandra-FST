package com.hacker.test.HackerCarInheritance;

public class WagonR extends Car{
	
	String carmileage;

	public WagonR(boolean isSedan, String seats, String mileage) {
		super(isSedan, seats);
		this.carmileage = mileage;
	}

	@Override
	public String getMileage() {
		return this.carmileage;
	}
}
