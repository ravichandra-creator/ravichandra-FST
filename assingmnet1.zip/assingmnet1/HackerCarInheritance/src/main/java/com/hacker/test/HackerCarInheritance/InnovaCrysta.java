package com.hacker.test.HackerCarInheritance;

public class InnovaCrysta extends Car {
	
String carmileage;
	
	public InnovaCrysta(boolean isSedan, String seats, String mileage) {
		super(isSedan, seats);
		this.carmileage = mileage;
	}

	@Override
	public String getMileage() {
		return this.carmileage;
	}

}
