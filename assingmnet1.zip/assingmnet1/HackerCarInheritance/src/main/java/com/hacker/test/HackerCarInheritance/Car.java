package com.hacker.test.HackerCarInheritance;

public abstract class Car {
	
	boolean isSedan;
	String seats;
	
	public Car(boolean isSedan, String seats) {
		super();
		this.isSedan = isSedan;
		this.seats = seats;
	}
	
	public boolean getIsSedan() {
		return this.isSedan;
	}
	
	public String getSeats() {
		return this.seats;
	}
	
	public abstract String getMileage();
}
