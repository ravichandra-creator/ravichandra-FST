package com.cap.rest.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Repository;

import com.cap.rest.model.Account;
import com.cap.rest.model.Customer;

@Repository
public class CustomerDaoImpl implements ICustomerDao {

	private static AtomicInteger customerId = new AtomicInteger(1);
	private static AtomicInteger accountId = new AtomicInteger(100);
	private static List<Customer> customerDb = dummyDB();

	private static List<Customer> dummyDB() {
		List<Customer> customer = new ArrayList<>();
		List<Account> account = new ArrayList<>();
		account.add(new Account(accountId.getAndIncrement(), "Savings", LocalDate.of(2000, 2, 12), 23000));
		account.add(new Account(accountId.getAndIncrement(), "Current", LocalDate.of(2000, 2, 22), 55000));
		customer.add(new Customer(customerId.getAndIncrement(), "Ram", "ram@gmail.com", "32434324", account));

		List<Account> account2 = new ArrayList<>();
		account2.add(new Account(accountId.getAndIncrement(), "Savings", LocalDate.of(2000, 2, 24), 56000));
		customer.add(new Customer(customerId.getAndIncrement(), "Sam", "sam@gmail.com", "5656565", account2));

		List<Account> account3 = new ArrayList<>();
		account3.add(new Account(accountId.getAndIncrement(), "Current", LocalDate.of(2000, 2, 14), 75000));
		customer.add(new Customer(customerId.getAndIncrement(), "Hari", "hari@gmail.com", "959977", account3));

		return customer;
	}

	public List<Customer> getAllCustomers() {

		return customerDb;
	}

	@Override
	public List<Customer> addCustomer(Customer customer) {
		customerDb.add(customer);
		return customerDb;
	}

	@Override
	public List<Customer> deleteCustomer(int customerId) {
		Customer cust = findCustomer(customerId);
		customerDb.remove(cust);
		return customerDb;
	}
	
	public Customer findCustomer(int customerId) {
		for (Customer custf : customerDb) {
			if (customerId == custf.getCustomerId())
				return custf;
		}
		return null;
	}
	
	@Override
	public List<Customer> updateCustomer(Customer customer) {
		for (Customer custom : customerDb) {
			if (custom.getCustomerId() == customer.getCustomerId()) {
				int index=customerDb.indexOf(custom);
				customerDb.set(index, customer);
			}
		}
		return customerDb;
	}

	@Override
	public List<Customer> putUpdateCustomer(Customer customer) {
		boolean flag = false;
		for (Customer custom : customerDb) {
			if (custom.getCustomerId() == customer.getCustomerId()) {
				flag = true;
				int index=customerDb.indexOf(custom);
				customerDb.set(index, customer);
			}
		}
		if(!flag) {
			customerDb.add(customer);
		}
		return customerDb;
	}
	
}
