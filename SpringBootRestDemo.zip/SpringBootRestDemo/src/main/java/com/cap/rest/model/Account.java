package com.cap.rest.model;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
public class Account {
	private int accountId;
	private String accountType;
	@JsonFormat(pattern = "dd-MMM-yyyy")
	private LocalDate openingDate=LocalDate.now();
	private double OpeningBalance;
	
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountNo(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public LocalDate getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}
	public double getOpeningBalance() {
		return OpeningBalance;
	}
	public void setOpeningBalance(double openingBalance) {
		OpeningBalance = openingBalance;
	}
	
	public Account() {
		super();
	}
	public Account(int accountId, String accountType, LocalDate openingDate, double openingBalance) {
		super();
		this.accountId = accountId;
		this.accountType = accountType;
		this.openingDate = openingDate;
		OpeningBalance = openingBalance;
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountType=" + accountType + ", openingDate=" + openingDate
				+ ", OpeningBalance=" + OpeningBalance + "]";
	}

}
