package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.Id;

//@Entity
public class Address {
	
	private String street;
	//@Id
	private String d_no;
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getD_no() {
		return d_no;
	}
	public void setD_no(String d_no) {
		this.d_no = d_no;
	}

}
